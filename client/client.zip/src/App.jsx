import LandingPage from './components/pages/LandingPage'
// import {ClerkProvider} from "@clerk/clerk-react"


 function App() {


  return (
    <>
      <LandingPage />

    </>
  )
}

export default App
